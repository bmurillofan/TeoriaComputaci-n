/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taller_punto_dos;

/**
 *
 * @author wezarkeVo
 */
public class Taller_punto_dos {
    
    public int index = 0;
    public boolean aceptacion = false;
    String Cadena = "acacaca";
    
    
     public boolean Evaluar(){
         
         while (index < Cadena.length()) {
            
             Q0();
             
         }
         
         
         return aceptacion;
     }
     
     
     public boolean Q0(){
          if(index < Cadena.length() && Cadena.charAt(index) == 'a'){
             index++;
             Q1();
      
         }else if (index < Cadena.length() && Cadena.charAt(index) == 'b') {
             index++;
             Q2();
         }else if (index < Cadena.length() && Cadena.charAt(index) == 'c'){
             index++;
             Q2();
         }else{
             aceptacion = false;
         }
         
         return aceptacion;
     }
     
     public boolean Q1(){
          if(index < Cadena.length() && Cadena.charAt(index) == 'b'){
           index++;
            aceptacion = true;
            Q3();
          }else if (index < Cadena.length() && Cadena.charAt(index) == 'c'){
              Q2();
          }else{
              aceptacion = false;
          }
         
         return aceptacion;
     }
     
     public boolean Q2(){
          if(index < Cadena.length() && Cadena.charAt(index) == 'a'){
           index++;
             Q1();
          }else if (index < Cadena.length() && Cadena.charAt(index) == 'b'){
              aceptacion = true;
              index++;
              Q3();
          }
         
         return aceptacion;
     }
     
     public boolean Q3(){
          if(index < Cadena.length() && Cadena.charAt(index) == 'a'){
             Q4();
          }

         return aceptacion;
     }
     
     public boolean Q4(){
          if(index < Cadena.length() && Cadena.charAt(index) == 'a'){
              aceptacion = true;
              index++;
              while (index < Cadena.length() && Cadena.charAt(index) == 'b') {
                  aceptacion = true;
                  index++;   
              }
              while (index < Cadena.length() && Cadena.charAt(index) == 'c') {
                  aceptacion = true;
                  index++;   
              }
          }
         
         return aceptacion;
     }
     
     
    
    
    public static void main(String[] args) {
        Taller_punto_dos obj = new Taller_punto_dos();
        if (obj.Evaluar()){ 
            System.out.println("Aceptada");
        }else{
            System.out.println("Rechazada");
        }
        
    }
}
